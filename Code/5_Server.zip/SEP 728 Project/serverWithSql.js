const express = require('express');
const dblite = require('dblite');
const app = express();

// Database setup
const db = dblite('./projectDatabase.sqlite3');
const images = dblite('./mage_store.sqlite3');

// Initialize tables if they don't exist
db.query("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, images TEXT, logs TEXT)");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set('view engine', 'pug');
app.use('/images', express.static('images'));

function addUser(newUser, callback) {
    const { username, password, images, logs } = newUser;
    const sql = "INSERT INTO users (username, password, images, logs) VALUES (?, ?, ?, ?)";

    db.query(sql, [username, password, JSON.stringify(images), JSON.stringify(logs)], (err) => {
        callback(err);
    });
}

function findUser(username, callback) {
    const sql = "SELECT * FROM users WHERE username = ?";

    db.query(sql, [username], (err, rows) => {
        if (err) {
            callback(err, null);
            return;
        }

        if (rows && rows.length > 0) {
            // Assuming rows is an array of arrays, where each inner array represents a row
            // Convert to an object
            const user = {
                id: rows[0][0],
                username: rows[0][1],
                password: rows[0][2],
                images: rows[0][3],
                logs: rows[0][4]
            };
            callback(null, user);
        } else {
            callback(null, null);
        }
    });
}

app.get('/', (req, res) => {
    res.render('home');
});

app.get("/login", (req, res) => {
    res.render('login');
});

app.get("/register", (req, res) => {
    res.render('register');
});

app.post("/logIn", (req, res) => {
    const username = req.body.userName;
    const password = req.body.userPassword;

    findUser(username, (err, user) => {
        if (err) {
            res.status(500).send("An error occurred");
            return;
        }
        if (user && user.password === password) {
            res.render('mainPage', { user: user });
        } else {
            res.status(500).send("Incorrect username or password");
        }
    });
});

app.post("/newUser", (req, res) => {
    let newUser = {
        username: req.body.username,
        password: req.body.password, 
        images: [],
        logs: []
    };

    findUser(newUser.username, (err, user) => {
        if (err) {
            res.status(500).send("An error occurred");
            return;
        }
        if (!user) {
            addUser(newUser, (err) => {
                if (err) {
                    res.status(500).send("An error occurred");
                    return;
                }
                res.redirect("/login");
            });
        } else {
            res.send("User already exists");
        }
    });
});

const port = 3000;
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
